import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";
import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";
import { checkCollision } from "./utils/collisions";

const ENEMY_SPEED = 0.03;
const ENEMY_SIZE = 1;
const DETECTION_RANGE = 5;
const ATTACK_RANGE = 1.2;
const ATTACK_COOLDOWN = 60; // frames (about 1 second at 60fps)

interface EnemyProps {
  initialPosition: [number, number];
  type: 'basic' | 'advanced';
  walls: any[];
}

export default function Enemy({ initialPosition, type, walls }: EnemyProps) {
  const enemyRef = useRef<THREE.Mesh>(null);
  const enemyTexture = useTexture("/textures/enemy.svg");
  const position = useRef(new THREE.Vector2(initialPosition[0], initialPosition[1]));
  const direction = useRef(new THREE.Vector2(0, 0));
  const attackCooldown = useRef(0);
  const { playerPosition, damagePlayer, gamePhase } = useGameState();
  const { playHit } = useAudio();
  
  // Animation state
  const [animationFrame, setAnimationFrame] = useState(0);
  const [facingDirection, setFacingDirection] = useState("down");
  const [isMoving, setIsMoving] = useState(false);
  const frameCount = 4; // Number of animation frames
  const frameDelay = 12; // Frames to wait between animation updates
  const frameTimer = useRef(0);

  // Enemy stats based on type
  const enemyStats = {
    basic: { health: 2, damage: 1, speed: ENEMY_SPEED },
    advanced: { health: 4, damage: 2, speed: ENEMY_SPEED * 1.2 }
  };
  
  const [health, setHealth] = useState(enemyStats[type].health);
  const speed = enemyStats[type].speed;
  const damage = enemyStats[type].damage;
  
  // Handle death
  useEffect(() => {
    if (health <= 0) {
      // Enemy is dead
      console.log("Enemy defeated!");
    }
  }, [health]);

  // Game loop for enemy behavior
  useFrame(() => {
    if (!enemyRef.current || gamePhase !== 'playing' || health <= 0) return;

    // Update attack cooldown
    if (attackCooldown.current > 0) {
      attackCooldown.current--;
    }

    const distanceToPlayer = new THREE.Vector2(
      playerPosition.x - position.current.x,
      playerPosition.y - position.current.y
    ).length();

    // Enemy behavior based on distance to player
    if (distanceToPlayer < DETECTION_RANGE) {
      // Move towards player
      direction.current.set(
        playerPosition.x - position.current.x,
        playerPosition.y - position.current.y
      ).normalize();
      
      // Set facing direction
      if (Math.abs(direction.current.x) > Math.abs(direction.current.y)) {
        setFacingDirection(direction.current.x > 0 ? "right" : "left");
      } else {
        setFacingDirection(direction.current.y > 0 ? "up" : "down");
      }
      
      setIsMoving(true);
      
      // Attack if in range and cooldown is finished
      if (distanceToPlayer < ATTACK_RANGE && attackCooldown.current === 0) {
        attackPlayer();
        attackCooldown.current = ATTACK_COOLDOWN;
      }
    } else {
      // Idle behavior - stand still or patrol
      direction.current.set(0, 0);
      setIsMoving(false);
    }

    // Movement logic
    if (isMoving) {
      // Calculate new position
      const newPosX = position.current.x + direction.current.x * speed;
      const newPosY = position.current.y + direction.current.y * speed;

      // Check for collisions
      const enemyBox = {
        x: newPosX - ENEMY_SIZE / 2,
        y: newPosY - ENEMY_SIZE / 2,
        width: ENEMY_SIZE,
        height: ENEMY_SIZE
      };

      let canMove = true;
      for (const wall of walls) {
        if (checkCollision(enemyBox, wall)) {
          canMove = false;
          break;
        }
      }

      // Update position if no collision
      if (canMove) {
        position.current.x = newPosX;
        position.current.y = newPosY;
        enemyRef.current.position.x = newPosX;
        enemyRef.current.position.z = -newPosY; // Note: z is reversed in our setup
      }

      // Animation handling
      frameTimer.current++;
      if (frameTimer.current >= frameDelay) {
        frameTimer.current = 0;
        setAnimationFrame((prevFrame) => (prevFrame + 1) % frameCount);
      }
    } else {
      setAnimationFrame(0); // Reset to standing frame when not moving
    }
  });

  const attackPlayer = () => {
    damagePlayer(damage);
    playHit();
    console.log(`Enemy attacks player for ${damage} damage!`);
  };

  const takeDamage = (amount: number) => {
    setHealth(prev => Math.max(0, prev - amount));
    playHit();
  };

  // Make enemy damage-able from outside
  useEffect(() => {
    if (enemyRef.current) {
      (enemyRef.current as any).takeDamage = takeDamage;
    }
  }, [enemyRef.current]);

  // Enemy color varies based on type
  const enemyColor = type === 'basic' ? "#aa5533" : "#882222";

  return (
    <mesh 
      ref={enemyRef} 
      position={[initialPosition[0], 0.5, -initialPosition[1]]} // z is negative y
      rotation={[0, 0, 0]}
    >
      <planeGeometry args={[ENEMY_SIZE, ENEMY_SIZE]} />
      <meshBasicMaterial 
        map={enemyTexture}
        color={enemyColor}
        transparent={true}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
