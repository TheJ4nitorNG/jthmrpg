import { useRef, useEffect, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useKeyboardControls } from "@react-three/drei";
import { useTexture } from "@react-three/drei";
import { Controls } from "./utils/controls";
import { useGameState } from "@/lib/stores/useGameState";
import { checkCollision } from "./utils/collisions";

interface PlayerProps {
  walls: Array<{ x: number; y: number; width: number; height: number; }>;
}

export default function Player({ walls }: PlayerProps) {
  const playerRef = useRef<THREE.Mesh>(null);
  const playerTexture = useTexture("/textures/johnny.svg");
  const direction = useRef(new THREE.Vector2(0, 0));
  const position = useRef(new THREE.Vector2(0, 0));
  const speed = 0.1;
  const size = 1;
  
  // Animation states
  const [animationFrame, setAnimationFrame] = useState(0);
  const [facingDirection, setFacingDirection] = useState("down");
  const [isMoving, setIsMoving] = useState(false);
  const frameCount = 4; // Number of animation frames
  const frameDelay = 8; // Frames to wait between animation updates
  const frameTimer = useRef(0);

  // Get keyboard controls
  const [subscribeKeys, getKeys] = useKeyboardControls();
  const { health, setPlayerPosition } = useGameState();

  // Subscribe to keyboard controls
  useEffect(() => {
    console.log("Setting up keyboard controls");
    
    const unsubscribeForward = subscribeKeys(
      (state) => state[Controls.forward],
      (pressed) => {
        console.log(`Forward key ${pressed ? "pressed" : "released"}`);
        direction.current.y = pressed ? 1 : 0;
        if (pressed) setFacingDirection("up");
        updateMovementState();
      }
    );

    const unsubscribeBackward = subscribeKeys(
      (state) => state[Controls.backward],
      (pressed) => {
        console.log(`Backward key ${pressed ? "pressed" : "released"}`);
        direction.current.y = pressed ? -1 : 0;
        if (pressed) setFacingDirection("down");
        updateMovementState();
      }
    );

    const unsubscribeLeftward = subscribeKeys(
      (state) => state[Controls.leftward],
      (pressed) => {
        console.log(`Leftward key ${pressed ? "pressed" : "released"}`);
        direction.current.x = pressed ? -1 : 0;
        if (pressed) setFacingDirection("left");
        updateMovementState();
      }
    );

    const unsubscribeRightward = subscribeKeys(
      (state) => state[Controls.rightward],
      (pressed) => {
        console.log(`Rightward key ${pressed ? "pressed" : "released"}`);
        direction.current.x = pressed ? 1 : 0;
        if (pressed) setFacingDirection("right");
        updateMovementState();
      }
    );

    // Also check current key states - for when component mounts with keys already pressed
    const keys = getKeys();
    if (keys[Controls.forward]) {
      direction.current.y = 1;
      setFacingDirection("up");
    } else if (keys[Controls.backward]) {
      direction.current.y = -1;
      setFacingDirection("down");
    }
    
    if (keys[Controls.leftward]) {
      direction.current.x = -1;
      setFacingDirection("left");
    } else if (keys[Controls.rightward]) {
      direction.current.x = 1;
      setFacingDirection("right");
    }
    
    updateMovementState();

    // Clean up subscriptions
    return () => {
      console.log("Cleaning up keyboard controls");
      unsubscribeForward();
      unsubscribeBackward();
      unsubscribeLeftward();
      unsubscribeRightward();
    };
  }, [subscribeKeys, getKeys]);

  const updateMovementState = () => {
    setIsMoving(direction.current.x !== 0 || direction.current.y !== 0);
  };

  // Game loop
  useFrame(() => {
    if (!playerRef.current) return;
    
    // Debug current state once every 30 frames to avoid console spam
    if (frameTimer.current % 30 === 0) {
      console.log("Player movement:", {
        phase: useGameState.getState().gamePhase, 
        direction: {x: direction.current.x, y: direction.current.y},
        position: {x: position.current.x, y: position.current.y},
        isMoving
      });
    }
    
    // Only move if in playing state, but always update directions
    const gamePhase = useGameState.getState().gamePhase;
    const playing = gamePhase === 'playing';
    
    // Get current key states directly in each frame for more responsive controls
    const keys = getKeys();
    const movementSpeed = speed * 3; // Increase speed to make movement more noticeable
    
    // Reset direction
    direction.current.set(0, 0);
    
    // Check movement keys and update direction
    if (keys[Controls.forward]) {
      direction.current.y = 1;
      setFacingDirection("up");
    } 
    if (keys[Controls.backward]) {
      direction.current.y = -1;
      setFacingDirection("down");
    }
    
    if (keys[Controls.leftward]) {
      direction.current.x = -1;
      setFacingDirection("left");
    } 
    if (keys[Controls.rightward]) {
      direction.current.x = 1;
      setFacingDirection("right");
    }
    
    // Update movement state based on current direction
    const isCurrentlyMoving = direction.current.x !== 0 || direction.current.y !== 0;
    setIsMoving(isCurrentlyMoving);
    
    if (!playing || !isCurrentlyMoving) {
      // Don't move if we're not in playing state or no direction
      return;
    }
    
    console.log(`Moving player in direction: (${direction.current.x}, ${direction.current.y})`);
    
    // Normalize diagonal movement
    if (direction.current.x !== 0 && direction.current.y !== 0) {
      direction.current.normalize();
    }

    // Calculate new position
    const newPosX = position.current.x + direction.current.x * movementSpeed;
    const newPosY = position.current.y + direction.current.y * movementSpeed;

    // Check for collisions
    const playerBox = {
      x: newPosX - size / 2,
      y: newPosY - size / 2,
      width: size,
      height: size
    };

    let canMove = true;
    for (const wall of walls) {
      if (checkCollision(playerBox, wall)) {
        canMove = false;
        console.log("Collision detected with wall:", wall);
        break;
      }
    }

    // Update position if no collision
    if (canMove) {
      position.current.x = newPosX;
      position.current.y = newPosY;
      
      // Update the actual mesh position
      if (playerRef.current) {
        playerRef.current.position.x = newPosX;
        playerRef.current.position.z = -newPosY; // Note: z is reversed in our setup
        
        // Also move the debug sphere
        const highlightMesh = playerRef.current.parent?.children[1];
        if (highlightMesh) {
          highlightMesh.position.x = newPosX;
          highlightMesh.position.z = -newPosY;
        }
      }
      
      // Update the global state
      setPlayerPosition({ x: newPosX, y: newPosY });
    }

    // Handle animation
    if (isMoving) {
      frameTimer.current++;
      if (frameTimer.current >= frameDelay) {
        frameTimer.current = 0;
        setAnimationFrame((prevFrame) => (prevFrame + 1) % frameCount);
      }
    } else {
      setAnimationFrame(0); // Reset to standing frame when not moving
    }
  });

  // Log key states for debugging
  useEffect(() => {
    const checkKeys = () => {
      const keys = getKeys();
      console.log("Current key states:", {
        forward: keys[Controls.forward],
        backward: keys[Controls.backward],
        leftward: keys[Controls.leftward],
        rightward: keys[Controls.rightward]
      });
    };
    
    // Check keys every second
    const interval = setInterval(checkKeys, 1000);
    return () => clearInterval(interval);
  }, [getKeys]);

  // Clear initial position on component mount
  useEffect(() => {
    if (playerRef.current) {
      // Set initial position
      position.current.set(8, 8); // Match playerStart from IntroLevel
      playerRef.current.position.set(position.current.x, 1.0, -position.current.y);
      setPlayerPosition({ x: position.current.x, y: position.current.y });
      console.log("Setting initial player mesh position:", position.current);
    }
  }, [playerRef, setPlayerPosition]);

  return (
    <>
      {/* Add a debug cube to make player visible */}
      <mesh 
        ref={playerRef} 
        position={[8, 1.0, -8]} // Start at playerStart from IntroLevel
        rotation={[0, 0, 0]}
      >
        <boxGeometry args={[1, 2, 1]} /> {/* Make player taller so it's easier to see */}
        <meshStandardMaterial color="#ff5555" /> {/* Bright red for visibility */}
      </mesh>
      
      {/* Add a debug sphere above the player to make it more visible */}
      <mesh position={[8, 2.5, -8]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial color="#ffff00" /> {/* Yellow highlight */}
      </mesh>
    </>
  );
}
