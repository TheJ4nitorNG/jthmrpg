import { useEffect } from "react";
import { useAudio } from "@/lib/stores/useAudio";
import { useGameState } from "@/lib/stores/useGameState";

export default function SoundManager() {
  const { backgroundMusic, isMuted } = useAudio();
  const { gamePhase } = useGameState();
  
  // Handle background music based on game phase
  useEffect(() => {
    if (!backgroundMusic) return;
    
    if (gamePhase === 'menu' || gamePhase === 'playing') {
      if (!isMuted) {
        backgroundMusic.volume = gamePhase === 'menu' ? 0.5 : 0.3;
        backgroundMusic.play().catch(error => {
          console.log("Background music play prevented:", error);
        });
      } else {
        backgroundMusic.pause();
      }
    } else if (gamePhase === 'paused') {
      // Reduce volume but don't pause completely
      backgroundMusic.volume = 0.1;
    }
    
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, gamePhase, isMuted]);
  
  // Listen for mute toggle
  useEffect(() => {
    if (!backgroundMusic) return;
    
    if (isMuted) {
      backgroundMusic.pause();
    } else if (gamePhase === 'menu' || gamePhase === 'playing') {
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
    }
  }, [isMuted, backgroundMusic, gamePhase]);
  
  // This component doesn't render anything
  return null;
}
