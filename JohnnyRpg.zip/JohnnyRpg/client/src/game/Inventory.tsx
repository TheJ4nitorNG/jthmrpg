import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGameState } from "@/lib/stores/useGameState";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "./utils/controls";

// Define interface for inventory items
interface InventoryItem {
  id: string;
  name: string;
  type: string;
  description: string;
  icon?: string;
  usable: boolean;
  quantity?: number;
  [key: string]: any;
}

export default function Inventory() {
  const { inventory, gamePhase, setGamePhase, previousGamePhase, setPreviousGamePhase } = useGameState();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [subscribeKeys, getKeys] = useKeyboardControls();

  // Toggle inventory with I key
  useEffect(() => {
    const unsubscribeInventory = subscribeKeys(
      (state) => state[Controls.inventory],
      (pressed) => {
        if (pressed) {
          toggleInventory();
        }
      }
    );
    
    return () => {
      unsubscribeInventory();
    };
  }, [subscribeKeys, gamePhase]);

  // Close inventory with ESC key
  useEffect(() => {
    const unsubscribePause = subscribeKeys(
      (state) => state[Controls.pause],
      (pressed) => {
        if (pressed && isOpen) {
          closeInventory();
        }
      }
    );
    
    return () => {
      unsubscribePause();
    };
  }, [subscribeKeys, isOpen]);

  const toggleInventory = () => {
    if (gamePhase === 'inventory') {
      closeInventory();
    } else if (gamePhase === 'playing' || gamePhase === 'paused') {
      openInventory();
    }
  };

  const openInventory = () => {
    setPreviousGamePhase(gamePhase);
    setGamePhase('inventory');
    setIsOpen(true);
  };

  const closeInventory = () => {
    setGamePhase(previousGamePhase);
    setIsOpen(false);
    setSelectedItem(null);
  };

  const selectItem = (item: InventoryItem) => {
    console.log("Selected item:", item);
    setSelectedItem(item);
  };

  const useItem = (item: InventoryItem) => {
    console.log("Using item:", item.name);
    // Implement item usage based on item type
    // This will vary by item
    
    // Close the item details
    setSelectedItem(null);
  };

  if (gamePhase !== 'inventory') return null;

  return (
    <div className="fixed inset-0 z-20 flex items-center justify-center bg-black bg-opacity-75">
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-gray-900 text-white w-full max-w-3xl p-6 rounded-lg border border-gray-700 shadow-lg"
        >
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-red-500">Inventory</h2>
            <button 
              onClick={closeInventory}
              className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded-md"
            >
              Close
            </button>
          </div>
          
          {inventory.length === 0 ? (
            <div className="text-center p-8 text-gray-400 italic">
              Your inventory is empty.
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-4">
              {inventory.map((item: InventoryItem, index: number) => (
                <div 
                  key={`inv-${index}`}
                  className={`p-2 bg-gray-800 rounded border ${selectedItem === item ? 'border-red-500' : 'border-gray-700'} 
                              hover:border-gray-500 cursor-pointer transition-colors`}
                  onClick={() => selectItem(item)}
                >
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 bg-gray-700 rounded flex items-center justify-center mb-2">
                      {/* Item icon would go here */}
                      <span>{item.icon || '?'}</span>
                    </div>
                    <span className="text-sm">{item.name}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {selectedItem && (
            <div className="mt-6 border-t border-gray-700 pt-4">
              <h3 className="text-xl font-bold mb-2">{selectedItem.name}</h3>
              <p className="text-gray-300 mb-4">{selectedItem.description}</p>
              
              <div className="flex justify-end space-x-4">
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="px-3 py-1 bg-gray-800 hover:bg-gray-700 rounded-md"
                >
                  Cancel
                </button>
                
                {selectedItem.usable && (
                  <button 
                    onClick={() => useItem(selectedItem)}
                    className="px-3 py-1 bg-red-900 hover:bg-red-800 rounded-md"
                  >
                    Use
                  </button>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
