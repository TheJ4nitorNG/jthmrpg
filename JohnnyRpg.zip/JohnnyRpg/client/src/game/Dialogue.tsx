import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGameState } from "@/lib/stores/useGameState";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "./utils/controls";

interface DialogueProps {
  onClose?: () => void;
}

export default function Dialogue({ onClose }: DialogueProps) {
  const { dialogue, setDialogue, gamePhase, setGamePhase } = useGameState();
  const [currentLine, setCurrentLine] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [subscribeKeys, getKeys] = useKeyboardControls();

  // Handle dialogue typing effect
  useEffect(() => {
    if (!dialogue || dialogue.lines.length === 0) return;
    
    setIsTyping(true);
    const fullText = dialogue.lines[currentLine].text;
    let charIndex = 0;
    
    const typingInterval = setInterval(() => {
      if (charIndex < fullText.length) {
        setDisplayedText(fullText.substring(0, charIndex + 1));
        charIndex++;
      } else {
        clearInterval(typingInterval);
        setIsTyping(false);
      }
    }, 30); // Speed of typing
    
    return () => clearInterval(typingInterval);
  }, [dialogue, currentLine]);

  // Handle keyboard advance
  useEffect(() => {
    const unsubscribeInteract = subscribeKeys(
      (state) => state[Controls.interact],
      (pressed) => {
        if (pressed && !isTyping && dialogue) {
          advanceDialogue();
        } else if (pressed && isTyping && dialogue) {
          // Skip typing and show full text
          setDisplayedText(dialogue.lines[currentLine].text);
          setIsTyping(false);
        }
      }
    );
    
    return () => {
      unsubscribeInteract();
    };
  }, [subscribeKeys, isTyping, dialogue, currentLine]);

  const advanceDialogue = () => {
    if (!dialogue) return;
    
    if (currentLine < dialogue.lines.length - 1) {
      setCurrentLine(prevLine => prevLine + 1);
    } else {
      // End of dialogue
      setDialogue(null);
      setGamePhase('playing');
      if (onClose) onClose();
    }
  };

  if (!dialogue || gamePhase !== 'dialogue') return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-10 p-4 bg-black bg-opacity-75">
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="max-w-4xl mx-auto p-4 bg-gray-800 text-white rounded-md border border-gray-700 shadow-lg"
        >
          <div className="flex">
            {dialogue.speaker && (
              <div className="mr-4 flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center text-center">
                  <span className="text-xs">{dialogue.speaker}</span>
                </div>
              </div>
            )}
            <div className="flex-grow">
              <h3 className="font-bold text-gray-300 mb-2">
                {dialogue.lines[currentLine].speaker || dialogue.speaker}
              </h3>
              <p className="text-gray-100 min-h-[3rem]">{displayedText}</p>
              
              {!isTyping && (
                <div className="mt-4 text-right">
                  <span className="text-sm text-gray-400 animate-pulse">
                    Press E to continue
                  </span>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
