import { LevelData } from "./index";

export default function NeighborsHouse(): LevelData {
  // Level dimensions
  const width = 20;
  const height = 20;
  
  // Walls - a regular suburban house layout, but with disturbing elements
  const walls = [
    // Boundary walls
    { x: 0, y: 0, width: width, height: 1 }, // Top wall
    { x: 0, y: 0, width: 1, height: height }, // Left wall
    { x: 0, y: height - 1, width: width, height: 1 }, // Bottom wall
    { x: width - 1, y: 0, width: 1, height: height }, // Right wall
    
    // House interior walls
    { x: 3, y: 3, width: 14, height: 1 }, // Living room top
    { x: 3, y: 3, width: 1, height: 14 }, // Living room left
    { x: 16, y: 3, width: 1, height: 14 }, // Living room right
    { x: 3, y: 16, width: 5, height: 1 }, // Living room bottom left
    { x: 11, y: 16, width: 6, height: 1 }, // Living room bottom right
    
    // Bedroom walls
    { x: 3, y: 8, width: 6, height: 1 }, // Bedroom top
    { x: 8, y: 8, width: 1, height: 5 }, // Bedroom right
    
    // Bathroom
    { x: 12, y: 8, width: 4, height: 1 }, // Bathroom top
    { x: 12, y: 8, width: 1, height: 5 }, // Bathroom left
    
    // Kitchen area
    { x: 9, y: 3, width: 1, height: 3 }, // Kitchen divider
  ];
  
  // Items in the neighbor's house
  const items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }> = [
    { id: "neighbors_journal", name: "Surveillance Journal", position: [7, 5], type: "note", usable: true,
      content: "I've been watching him. Johnny is definitely up to something terrible. The screams at night..." },
    { id: "camera", name: "Spy Camera", position: [14, 5], type: "tool", usable: true,
      description: "A small camera, likely used to spy on people. It has footage of Johnny's house." },
    { id: "medicine", name: "Strange Medicine", position: [14, 12], type: "healing", usable: true,
      healAmount: 2, description: "Some kind of prescription medication. Makes you feel strange." },
    { id: "evidence", name: "Evidence Box", position: [5, 14], type: "container", usable: true,
      content: "Photos, notes, and recordings - all documenting Johnny's activities. Disturbing." }
  ];
  
  // NPCs in the neighbor's house
  const npcs: Array<{
    id: string;
    name: string;
    position: [number, number];
    dialogue: {
      speaker: string;
      lines: Array<{ text: string; speaker?: string }>;
    };
  }> = [
    { 
      id: "paranoid_neighbor", 
      name: "Nervous Neighbor", 
      position: [10, 5], 
      dialogue: {
        speaker: "Neighbor",
        lines: [
          { text: "Johnny?! What are you doing in my house?!" },
          { text: "I've been watching you. I know what you're doing in that basement..." },
          { text: "Stay back! I've called the police already! They'll find all the evidence!" },
          { text: "You're a monster! I've seen the people you bring home who never leave!" }
        ]
      }
    },
    { 
      id: "hiding_child", 
      name: "Frightened Child", 
      position: [6, 10], 
      dialogue: {
        speaker: "Child",
        lines: [
          { text: "Please don't hurt me! Daddy said you're a bad man..." },
          { text: "I've seen you watching our house from your window." },
          { text: "I'm not supposed to talk to you. Please go away!" }
        ]
      }
    }
  ];
  
  // Enemies - neighbor's security measures
  const enemies: Array<{
    id: string;
    type: "basic" | "advanced";
    position: [number, number];
    patrol?: Array<[number, number]>;
  }> = [
    { id: "guard_dog", type: "basic", position: [8, 14],
      patrol: [[8, 14], [14, 14], [14, 10], [8, 10]] }
  ];
  
  // Objectives
  const objectives: Array<{
    id: string;
    text: string;
    completed: boolean;
    [key: string]: any;
  }> = [
    { id: "find_evidence", text: "Discover what your neighbor knows about you", completed: false, targetItemId: "evidence" },
    { id: "confront_neighbor", text: "Confront your paranoid neighbor", completed: false, targetNpcId: "paranoid_neighbor" },
    { id: "avoid_detection", text: "Avoid alerting authorities", completed: false }
  ];
  
  // Initial player position
  const playerStart = { x: 2, y: 12 };
  
  // Intro dialogue when entering the neighbor's house
  const introDialogue = {
    speaker: "Johnny",
    lines: [
      { text: "So this is where my neighbor lives... they've been watching me." },
      { text: "I need to find out what they know. What evidence they've collected." },
      { text: "I can feel the walls closing in. They won't let me continue my work..." }
    ]
  };
  
  // Exit points
  const exits: Array<{
    id: string;
    position: { x: number; y: number; width: number; height: number };
    targetLevel: string;
    targetPosition: { x: number; y: number };
    needsKey?: string;
  }> = [
    { 
      id: "front_door", 
      position: { x: 8, y: 16, width: 3, height: 1 }, 
      targetLevel: "johnnys-house", 
      targetPosition: { x: 20, y: 12 } 
    },
    { 
      id: "to_hub", 
      position: { x: 2, y: 2, width: 1, height: 1 }, 
      targetLevel: "intro", 
      targetPosition: { x: 10, y: 10 } 
    }
  ];
  
  // Return the complete level data
  return {
    name: "Neighbor's House",
    layout: { width, height },
    walls,
    items,
    npcs,
    enemies,
    objectives,
    playerStart,
    introDialogue,
    exits
  };
}