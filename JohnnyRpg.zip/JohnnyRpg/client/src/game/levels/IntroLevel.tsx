import { LevelData } from "./index";

export default function IntroLevel(): LevelData {
  // Level dimensions
  const width = 20;
  const height = 20;
  
  // Simple walls creating a contained area
  const walls = [
    // Outer walls
    { x: 0, y: 0, width: width, height: 1 }, // Top wall
    { x: 0, y: 0, width: 1, height: height }, // Left wall
    { x: 0, y: height - 1, width: width, height: 1 }, // Bottom wall
    { x: width - 1, y: 0, width: 1, height: height }, // Right wall
    
    // Interior decorative walls
    { x: 5, y: 3, width: 3, height: 1 },
    { x: 12, y: 3, width: 3, height: 1 },
    { x: 8, y: 16, width: 4, height: 1 },
  ];
  
  // Each NPC represents a level portal with appropriate dialogue
  const npcs = [
    { 
      id: "johnnys_house_guide", 
      name: "Johnny's House Portal", 
      position: [5, 7] as [number, number], 
      dialogue: {
        speaker: "Voice",
        lines: [
          { text: "Enter Johnny's House? This is where your journey begins." },
          { text: "The horrors await within your own walls..." }
        ]
      }
    },
    { 
      id: "wasteland_guide", 
      name: "Wasteland Portal", 
      position: [10, 7] as [number, number], 
      dialogue: {
        speaker: "Voice",
        lines: [
          { text: "Enter The Wasteland? A desolate place between worlds." },
          { text: "Reality bends and shifts here, testing your sanity." }
        ]
      }
    },
    { 
      id: "heaven_guide", 
      name: "Heaven Portal", 
      position: [15, 7] as [number, number], 
      dialogue: {
        speaker: "Voice",
        lines: [
          { text: "Enter The Heaven Realm? Not heaven as you imagined it." },
          { text: "Answers lie within this ethereal space, if you can comprehend them." }
        ]
      }
    },
    { 
      id: "neighbors_guide", 
      name: "Neighbor's House Portal", 
      position: [10, 12] as [number, number], 
      dialogue: {
        speaker: "Voice",
        lines: [
          { text: "Enter Your Neighbor's House? The one who's been watching you." },
          { text: "What secrets do they know about your activities?" }
        ]
      }
    }
  ];
  
  // No items in the hub level
  const items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }> = [];
  
  // No enemies in the hub level
  const enemies: Array<{
    id: string;
    type: "basic" | "advanced";
    position: [number, number];
    patrol?: Array<[number, number]>;
  }> = [];
  
  // Objectives - choose a level to explore
  const objectives = [
    { id: "choose_level", text: "Choose a level to explore", completed: false }
  ];
  
  // Initial player position
  const playerStart = { x: 10, y: 10 };
  
  // Level entry dialogue
  const introDialogue = {
    speaker: "Johnny",
    lines: [
      { text: "Where am I? This place... it's like a nexus between realms." },
      { text: "I can feel different places calling to me..." },
      { text: "Which horror shall I face first?" }
    ]
  };
  
  // Exit points to other levels
  const exits = [
    { 
      id: "to_johnnys_house", 
      position: { x: 5, y: 7, width: 1, height: 1 }, 
      targetLevel: "johnnys-house", 
      targetPosition: { x: 8, y: 8 } 
    },
    { 
      id: "to_wasteland", 
      position: { x: 10, y: 7, width: 1, height: 1 }, 
      targetLevel: "wasteland", 
      targetPosition: { x: 12, y: 20 } 
    },
    { 
      id: "to_heaven", 
      position: { x: 15, y: 7, width: 1, height: 1 }, 
      targetLevel: "heaven", 
      targetPosition: { x: 2, y: 15 } 
    },
    { 
      id: "to_neighbors_house", 
      position: { x: 10, y: 12, width: 1, height: 1 }, 
      targetLevel: "neighbors-house", 
      targetPosition: { x: 2, y: 12 } 
    }
  ];
  
  // Return the complete level data
  return {
    name: "Level Selection Hub",
    layout: { width, height },
    walls,
    items,
    npcs,
    enemies,
    objectives,
    playerStart,
    introDialogue,
    exits
  };
}