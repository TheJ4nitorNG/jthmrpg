import { LevelData } from "./index";

export default function HeavenLevel(): LevelData {
  // Level dimensions
  const width = 25;
  const height = 25;
  
  // Walls - create a heavenly but unsettling environment
  const walls = [
    // Boundary walls
    { x: 0, y: 0, width: width, height: 1 }, // Top wall
    { x: 0, y: 0, width: 1, height: height }, // Left wall
    { x: 0, y: height - 1, width: width, height: 1 }, // Bottom wall
    { x: width - 1, y: 0, width: 1, height: height }, // Right wall
    
    // Bizarre heavenly architecture
    { x: 5, y: 5, width: 15, height: 1 }, // Upper structure
    { x: 5, y: 5, width: 1, height: 15 }, // Left structure
    { x: 19, y: 5, width: 1, height: 15 }, // Right structure
    { x: 5, y: 19, width: 15, height: 1 }, // Lower structure
    
    // Inner sanctum walls
    { x: 10, y: 10, width: 5, height: 1 }, // Inner top wall
    { x: 10, y: 10, width: 1, height: 5 }, // Inner left wall
    { x: 14, y: 10, width: 1, height: 5 }, // Inner right wall
    { x: 10, y: 14, width: 5, height: 1 }, // Inner bottom wall
    
    // Angelic statues (represented as small wall blocks)
    { x: 7, y: 7, width: 1, height: 1 },
    { x: 17, y: 7, width: 1, height: 1 },
    { x: 7, y: 17, width: 1, height: 1 },
    { x: 17, y: 17, width: 1, height: 1 },
  ];
  
  // Items in Heaven
  const items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }> = [
    { id: "divine_weapon", name: "Angelic Blade", position: [12, 12], type: "weapon", usable: false,
      damage: 10, description: "A blade that seems to cut through more than just physical matter." },
    { id: "revelation", name: "Book of Truths", position: [17, 12], type: "note", usable: true,
      content: "All things, even Heaven, are constructs of your mind. Reality exists only in perception." },
    { id: "ambrosia", name: "Ethereal Nectar", position: [8, 8], type: "healing", usable: true,
      healAmount: 10, description: "Heals both body and spirit, though neither truly exists here." }
  ];
  
  // NPCs in Heaven
  const npcs: Array<{
    id: string;
    name: string;
    position: [number, number];
    dialogue: {
      speaker: string;
      lines: Array<{ text: string; speaker?: string }>;
    };
  }> = [
    { 
      id: "god", 
      name: "Divine Entity", 
      position: [12, 7], 
      dialogue: {
        speaker: "Entity",
        lines: [
          { text: "So you've made it to Heaven, Johnny. Impressive, for a mortal mind." },
          { text: "Do you understand yet that your reality is merely a construct? Your actions, your sins..." },
          { text: "They're only as real as you believe them to be. This place, too, exists only in your mind." },
          { text: "Release yourself from the burden of perception, and you might find peace." }
        ]
      }
    },
    { 
      id: "dead_victim", 
      name: "Ethereal Victim", 
      position: [7, 12], 
      dialogue: {
        speaker: "Spirit",
        lines: [
          { text: "Why did you kill me, Johnny? What did I ever do to deserve that?" },
          { text: "In death, I see now... you're trapped in a cycle of your own making." },
          { text: "I forgive you, not because you deserve it, but because hate would only trap me like you." }
        ]
      }
    }
  ];
  
  // Enemies - angelic but threatening beings
  const enemies: Array<{
    id: string;
    type: "basic" | "advanced";
    position: [number, number];
    patrol?: Array<[number, number]>;
  }> = [
    { id: "seraphim", type: "advanced", position: [18, 18] },
    { id: "cherubim", type: "advanced", position: [6, 18],
      patrol: [[6, 18], [6, 6], [18, 6], [18, 18]] }
  ];
  
  // Objectives
  const objectives: Array<{
    id: string;
    text: string;
    completed: boolean;
    [key: string]: any;
  }> = [
    { id: "face_judgment", text: "Face divine judgment", completed: false, targetNpcId: "god" },
    { id: "confront_victims", text: "Confront your victims in the afterlife", completed: false, targetNpcId: "dead_victim" },
    { id: "obtain_revelation", text: "Gain cosmic understanding", completed: false, targetItemId: "revelation" }
  ];
  
  // Initial player position
  const playerStart = { x: 2, y: 15 };
  
  // Intro dialogue when entering Heaven
  const introDialogue = {
    speaker: "Johnny",
    lines: [
      { text: "This is... Heaven? It doesn't feel right. Too sterile. Too perfect." },
      { text: "The air itself seems to judge me, to know what I've done." },
      { text: "I can feel the weight of every life I've taken here. They're watching me." }
    ]
  };
  
  // Exit points
  const exits: Array<{
    id: string;
    position: { x: number; y: number; width: number; height: number };
    targetLevel: string;
    targetPosition: { x: number; y: number };
    needsKey?: string;
  }> = [
    { 
      id: "heaven_exit", 
      position: { x: 1, y: 15, width: 1, height: 2 }, 
      targetLevel: "wasteland", 
      targetPosition: { x: 27, y: 15 } 
    },
    { 
      id: "to_hub", 
      position: { x: 22, y: 22, width: 1, height: 1 }, 
      targetLevel: "intro", 
      targetPosition: { x: 10, y: 10 } 
    }
  ];
  
  // Return the complete level data
  return {
    name: "Heaven",
    layout: { width, height },
    walls,
    items,
    npcs,
    enemies,
    objectives,
    playerStart,
    introDialogue,
    exits
  };
}