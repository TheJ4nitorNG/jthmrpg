import { LevelData } from "./index";

export default function Wasteland(): LevelData {
  // Level dimensions
  const width = 30;
  const height = 30;
  
  // Walls - create a more open, desolate environment
  const walls = [
    // Boundary walls
    { x: 0, y: 0, width: width, height: 1 }, // Top wall
    { x: 0, y: 0, width: 1, height: height }, // Left wall
    { x: 0, y: height - 1, width: width, height: 1 }, // Bottom wall
    { x: width - 1, y: 0, width: 1, height: height }, // Right wall
    
    // Scattered debris and wasteland features
    { x: 5, y: 5, width: 3, height: 2 }, // Destroyed building
    { x: 15, y: 8, width: 4, height: 3 }, // Large debris pile
    { x: 8, y: 15, width: 2, height: 2 }, // Small wreckage
    { x: 20, y: 15, width: 3, height: 3 }, // Ruined structure
    { x: 10, y: 22, width: 6, height: 1 }, // Broken wall
    { x: 22, y: 20, width: 1, height: 5 }, // Strange pillar
  ];
  
  // Items scattered throughout the wasteland
  const items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }> = [
    { id: "strange_device", name: "Strange Device", position: [8, 7], type: "tool", usable: true,
      description: "A mysterious device that seems to distort reality around it." },
    { id: "heaven_key", name: "Ethereal Key", position: [22, 12], type: "key", usable: true,
      description: "A key that seems to be made of light rather than matter. It hums faintly." },
    { id: "wasteland_map", name: "Tattered Map", position: [14, 18], type: "note", usable: true,
      content: "A barely legible map showing strange landmarks throughout the wasteland." },
    { id: "healing_shard", name: "Crystallized Memory", position: [5, 22], type: "healing", usable: true,
      healAmount: 5, description: "A fragment of a happier memory crystallized into physical form." }
  ];
  
  // NPCs in the wasteland
  const npcs: Array<{
    id: string;
    name: string;
    position: [number, number];
    dialogue: {
      speaker: string;
      lines: Array<{ text: string; speaker?: string }>;
    };
  }> = [
    { 
      id: "doughboy", 
      name: "Mr. Eff", 
      position: [10, 10], 
      dialogue: {
        speaker: "Mr. Eff",
        lines: [
          { text: "Well, look who's wandering about! Lost your way, Johnny boy?" },
          { text: "The wasteland is where your mind goes when you can't bear reality anymore." },
          { text: "Enjoying your little trip? The things you've done, Johnny... tsk tsk..." },
          { text: "I'm always here, you know. In the back of your mind. WAITING." }
        ]
      }
    },
    { 
      id: "psychic_ghost", 
      name: "Spectral Entity", 
      position: [20, 25], 
      dialogue: {
        speaker: "Entity",
        lines: [
          { text: "You exist between worlds now, half here, half there..." },
          { text: "The key you seek opens more than just doors. It opens perception." },
          { text: "Heaven isn't what you think it is. None of this is." }
        ]
      }
    }
  ];
  
  // Enemies wandering the wasteland
  const enemies: Array<{
    id: string;
    type: "basic" | "advanced";
    position: [number, number];
    patrol?: Array<[number, number]>;
  }> = [
    { id: "wasteland_creature1", type: "basic", position: [15, 15], 
      patrol: [[15, 15], [15, 20], [20, 20], [20, 15]] },
    { id: "wasteland_creature2", type: "basic", position: [7, 25] },
    { id: "reality_horror", type: "advanced", position: [24, 7], 
      patrol: [[24, 7], [24, 15], [15, 15], [15, 7]] }
  ];
  
  // Objectives
  const objectives: Array<{
    id: string;
    text: string;
    completed: boolean;
    [key: string]: any;
  }> = [
    { id: "find_heaven_key", text: "Find the key to Heaven", completed: false, targetItemId: "heaven_key" },
    { id: "meet_doughboy", text: "Confront your inner voice", completed: false, targetNpcId: "doughboy" },
    { id: "wasteland_survival", text: "Survive the wasteland horrors", completed: false, 
      targetEnemyIds: ["wasteland_creature1", "wasteland_creature2", "reality_horror"] }
  ];
  
  // Initial player position
  const playerStart = { x: 12, y: 20 };
  
  // Intro dialogue when entering the wasteland
  const introDialogue = {
    speaker: "Johnny",
    lines: [
      { text: "This place... it feels wrong. Like reality itself is broken here." },
      { text: "The sky looks like it's bleeding. Is this even real?" },
      { text: "I can hear whispers on the wind. My own thoughts feel... contaminated." }
    ]
  };
  
  // Exit points to other areas
  const exits: Array<{
    id: string;
    position: { x: number; y: number; width: number; height: number };
    targetLevel: string;
    targetPosition: { x: number; y: number };
    needsKey?: string;
  }> = [
    { 
      id: "back_to_house", 
      position: { x: 12, y: 28, width: 2, height: 1 }, 
      targetLevel: "johnnys-house", 
      targetPosition: { x: 7, y: 9 } 
    },
    { 
      id: "to_heaven", 
      position: { x: 28, y: 15, width: 1, height: 2 }, 
      targetLevel: "heaven", 
      targetPosition: { x: 2, y: 15 },
      needsKey: "heaven_key"
    },
    { 
      id: "to_hub", 
      position: { x: 2, y: 2, width: 1, height: 1 }, 
      targetLevel: "intro", 
      targetPosition: { x: 10, y: 10 } 
    }
  ];
  
  // Return the complete level data
  return {
    name: "The Wasteland",
    layout: { width, height },
    walls,
    items,
    npcs,
    enemies,
    objectives,
    playerStart,
    introDialogue,
    exits
  };
}