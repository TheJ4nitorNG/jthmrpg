import { LevelData } from "./index";

export default function JohnnysHouse(): LevelData {
  // Level dimensions
  const width = 25;
  const height = 25;
  
  // Level elements
  const walls = [
    // Outer walls
    { x: 0, y: 0, width: width, height: 1 }, // Top wall
    { x: 0, y: 0, width: 1, height: height }, // Left wall
    { x: 0, y: height - 1, width: width, height: 1 }, // Bottom wall
    { x: width - 1, y: 0, width: 1, height: height }, // Right wall
    
    // Interior walls - Johnny's house
    { x: 5, y: 5, width: 7, height: 1 }, // Living room top
    { x: 5, y: 5, width: 1, height: 6 }, // Living room left
    { x: 11, y: 5, width: 1, height: 6 }, // Living room right
    { x: 5, y: 10, width: 2, height: 1 }, // Living room bottom left
    { x: 8, y: 10, width: 4, height: 1 }, // Living room bottom right
    
    // Basement entry
    { x: 7, y: 10, width: 1, height: 3 }, // Left wall of entry
    { x: 8, y: 12, width: 3, height: 1 }, // Bottom of entry
    { x: 10, y: 10, width: 1, height: 3 }, // Right wall of entry
    
    // Basement walls
    { x: 3, y: 15, width: 4, height: 1 }, // Upper left wall
    { x: 3, y: 15, width: 1, height: 5 }, // Left wall
    { x: 3, y: 19, width: 14, height: 1 }, // Bottom wall
    { x: 11, y: 15, width: 6, height: 1 }, // Upper right wall
    { x: 16, y: 15, width: 1, height: 5 }, // Right wall
  ];
  
  // Items - keys, healing items, notes
  const items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }> = [
    { id: "basement_key", name: "Basement Key", position: [9, 8], type: "key", usable: true },
    { id: "diary", name: "Strange Diary", position: [7, 7], type: "note", usable: true, 
      content: "The voices won't stop. I need to find a way to silence them..." },
    { id: "healing_item", name: "First Aid Kit", position: [14, 17], type: "healing", usable: true, 
      healAmount: 3 },
    { id: "weapon", name: "Knife", position: [5, 18], type: "weapon", usable: false, 
      damage: 2 },
    { id: "neighbors_key", name: "Neighbor's Key", position: [15, 18], type: "key", usable: true,
      description: "A key to the neighbor's house. How did it get here?" }
  ];
  
  // NPCs with dialogue
  const npcs: Array<{
    id: string;
    name: string;
    position: [number, number];
    dialogue: {
      speaker: string;
      lines: Array<{ text: string; speaker?: string }>;
    };
  }> = [
    { 
      id: "neighbor", 
      name: "Nervous Neighbor", 
      position: [13, 7], 
      dialogue: {
        speaker: "Neighbor",
        lines: [
          { text: "Oh... it's you, Johnny. You've been acting strange lately." },
          { text: "The screaming from your basement has been keeping everyone up at night." },
          { text: "I, uh... I should go. Stay away from me, okay?" }
        ]
      }
    },
    { 
      id: "captured_victim", 
      name: "Captured Victim", 
      position: [8, 17], 
      dialogue: {
        speaker: "Victim",
        lines: [
          { text: "Please let me go! I didn't do anything to you!" },
          { text: "Why are you keeping me here? What are those things on the wall?!" },
          { text: "Oh god, you're not listening... your eyes... they're not human..." }
        ]
      }
    }
  ];
  
  // Enemies
  const enemies: Array<{
    id: string;
    type: "basic" | "advanced";
    position: [number, number];
    patrol?: Array<[number, number]>;
  }> = [
    { id: "hallucination1", type: "basic", position: [6, 16], patrol: [[6, 16], [6, 18], [10, 18], [10, 16]] },
    { id: "hallucination2", type: "advanced", position: [14, 16] }
  ];
  
  // Objectives
  const objectives: Array<{
    id: string;
    text: string;
    completed: boolean;
    [key: string]: any;
  }> = [
    { id: "find_key", text: "Find the basement key", completed: false, targetItemId: "basement_key" },
    { id: "enter_basement", text: "Enter the basement", completed: false, targetArea: { x: 8, y: 13, width: 2, height: 2 } },
    { id: "confront_demons", text: "Confront your inner demons", completed: false, targetEnemyIds: ["hallucination1", "hallucination2"] },
    { id: "find_neighbors_key", text: "Find a way into the neighbor's house", completed: false, targetItemId: "neighbors_key" }
  ];
  
  // Initial player position
  const playerStart = { x: 8, y: 8 };
  
  // Level entry dialogue
  const introDialogue = {
    speaker: "Johnny",
    lines: [
      { text: "Another sleepless night. The voices are getting louder..." },
      { text: "I need to go check on my... 'guest' in the basement." },
      { text: "Where did I put that key?" }
    ]
  };
  
  // Exit points to other levels
  const exits = [
    { 
      id: "front_door", 
      position: { x: 7, y: 10, width: 1, height: 1 }, 
      targetLevel: "wasteland", 
      targetPosition: { x: 12, y: 20 } 
    },
    { 
      id: "to_neighbors_house", 
      position: { x: 20, y: 12, width: 1, height: 1 }, 
      targetLevel: "neighbors-house", 
      targetPosition: { x: 2, y: 12 },
      needsKey: "neighbors_key" // Special property for locked exits
    }
  ];
  
  // Return the complete level data
  return {
    name: "Johnny's House",
    layout: { width, height },
    walls,
    items,
    npcs,
    enemies,
    objectives,
    playerStart,
    introDialogue,
    exits
  };
}