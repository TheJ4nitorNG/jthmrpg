import IntroLevel from './IntroLevel';
import JohnnysHouse from './JohnnysHouse';
import Wasteland from './Wasteland';
import HeavenLevel from './HeavenLevel';
import NeighborsHouse from './NeighborsHouse';

// Define the level structure for type checking
export interface LevelData {
  name: string;
  layout: { width: number; height: number };
  walls: Array<{ x: number; y: number; width: number; height: number }>;
  items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }>;
  npcs: Array<{
    id: string;
    name: string;
    position: [number, number];
    dialogue: {
      speaker: string;
      lines: Array<{ text: string; speaker?: string }>;
    };
  }>;
  enemies: Array<{
    id: string;
    type: 'basic' | 'advanced';
    position: [number, number];
    patrol?: Array<[number, number]>;
  }>;
  objectives: Array<{
    id: string;
    text: string;
    completed: boolean;
    [key: string]: any;
  }>;
  playerStart: { x: number; y: number };
  introDialogue: {
    speaker: string;
    lines: Array<{ text: string; speaker?: string }>;
  };
  exits: Array<{
    id: string;
    position: { x: number; y: number; width: number; height: number };
    targetLevel: string;
    targetPosition: { x: number; y: number };
    needsKey?: string; // Optional - ID of the key item needed to use this exit
  }>;
}

// Map level IDs to their loading functions
export const levelMap: Record<string, () => LevelData> = {
  'intro': IntroLevel,
  'johnnys-house': JohnnysHouse,
  'wasteland': Wasteland,
  'heaven': HeavenLevel,
  'neighbors-house': NeighborsHouse
};

// Load a level by ID
export function loadLevel(levelId: string): LevelData | null {
  const levelLoader = levelMap[levelId];
  if (!levelLoader) {
    console.error(`Level with ID "${levelId}" not found!`);
    return null;
  }
  
  return levelLoader();
}

// Get a list of all available level IDs
export function getAllLevelIds(): string[] {
  return Object.keys(levelMap);
}

// Get the total number of levels
export function getLevelCount(): number {
  return Object.keys(levelMap).length;
}