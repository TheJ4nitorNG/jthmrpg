import * as THREE from "three";
import { useTexture } from "@react-three/drei";
import { useState, useEffect, useRef, forwardRef, useImperativeHandle } from "react";

interface PixelSpriteProps {
  texture: string;
  position: [number, number, number];
  size?: number;
  color?: string;
  rotation?: number;
  opacity?: number;
}

// A reusable sprite component that handles pixel art sprites
export function PixelSprite({ 
  texture, 
  position, 
  size = 1, 
  color = "white",
  rotation = 0,
  opacity = 1
}: PixelSpriteProps) {
  const spriteTexture = useTexture(texture);
  
  // Make sure the texture uses nearest-neighbor filtering for pixel art
  if (spriteTexture) {
    if (spriteTexture instanceof THREE.Texture) {
      spriteTexture.magFilter = THREE.NearestFilter;
      spriteTexture.minFilter = THREE.NearestFilter;
      spriteTexture.generateMipmaps = false;
    }
  }
  
  return (
    <sprite 
      position={[position[0], position[1], position[2]]} 
      scale={[size, size, 1]}
      rotation={[0, 0, rotation]}
    >
      <spriteMaterial 
        map={spriteTexture instanceof THREE.Texture ? spriteTexture : undefined} 
        color={color} 
        transparent={true}
        opacity={opacity}
      />
    </sprite>
  );
}

interface AnimatedSpriteProps {
  textures: string[];
  position: [number, number, number];
  size?: number;
  color?: string;
  rotation?: number;
  frameRate?: number;
  loop?: boolean;
  play?: boolean;
}

// Animated sprite component that cycles through animation frames
export const AnimatedSprite = forwardRef(({
  textures, // Array of texture paths for animation frames
  position,
  size = 1,
  color = "white",
  rotation = 0,
  frameRate = 8, // Frames per second
  loop = true, // Whether to loop the animation
  play = true, // Whether the animation is playing
}: AnimatedSpriteProps, ref) => {
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(play);
  const frameCount = textures.length;
  const textureMaps = textures.map(path => useTexture(path));
  
  // Configure all textures for pixel art
  textureMaps.forEach(texture => {
    if (texture && texture instanceof THREE.Texture) {
      texture.magFilter = THREE.NearestFilter;
      texture.minFilter = THREE.NearestFilter;
      texture.generateMipmaps = false;
    }
  });
  
  // Animation loop
  useEffect(() => {
    if (!isPlaying || frameCount <= 1) return;
    
    const interval = setInterval(() => {
      setCurrentFrame(prev => {
        if (prev < frameCount - 1) return prev + 1;
        if (loop) return 0;
        setIsPlaying(false);
        return prev;
      });
    }, 1000 / frameRate);
    
    return () => clearInterval(interval);
  }, [isPlaying, frameCount, frameRate, loop]);
  
  // Methods to control animation
  const playAnimation = () => setIsPlaying(true);
  const pauseAnimation = () => setIsPlaying(false);
  const resetAnimation = () => setCurrentFrame(0);
  
  // Expose methods to parent through ref
  useImperativeHandle(ref, () => ({
    play: playAnimation,
    pause: pauseAnimation,
    reset: resetAnimation,
    isPlaying: isPlaying
  }));
  
  const currentTexture = textureMaps[currentFrame];
  const textureToUse = currentTexture instanceof THREE.Texture ? currentTexture : undefined;
  
  return (
    <sprite 
      position={[position[0], position[1], position[2]]} 
      scale={[size, size, 1]}
      rotation={[0, 0, rotation]}
    >
      <spriteMaterial 
        map={textureToUse} 
        color={color} 
        transparent={true}
      />
    </sprite>
  );
});
