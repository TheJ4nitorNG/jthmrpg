import { useState, useEffect } from "react";
import { useGameState } from "@/lib/stores/useGameState";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "./utils/controls";
import { useAudio } from "@/lib/stores/useAudio";
import Dialogue from "./Dialogue";
import Inventory from "./Inventory";

export default function GameUI() {
  const { health, maxHealth, gamePhase, setGamePhase, setPreviousGamePhase } = useGameState();
  const { toggleMute, isMuted } = useAudio();
  const [subscribeKeys, getKeys] = useKeyboardControls();
  const [showPauseMenu, setShowPauseMenu] = useState(false);

  // Handle pause toggle with ESC key
  useEffect(() => {
    const unsubscribePause = subscribeKeys(
      (state) => state[Controls.pause],
      (pressed) => {
        if (pressed && gamePhase === 'playing') {
          togglePause();
        } else if (pressed && gamePhase === 'paused') {
          resumeGame();
        }
      }
    );
    
    return () => {
      unsubscribePause();
    };
  }, [subscribeKeys, gamePhase]);

  const togglePause = () => {
    setPreviousGamePhase(gamePhase);
    setGamePhase('paused');
    setShowPauseMenu(true);
  };

  const resumeGame = () => {
    setGamePhase('playing');
    setShowPauseMenu(false);
  };

  const exitToMenu = () => {
    setGamePhase('menu');
    setShowPauseMenu(false);
  };

  return (
    <>
      {/* Health bar and basic UI */}
      <div className="fixed top-0 left-0 right-0 p-4 z-10">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center space-x-2">
            <div className="text-white font-bold">Health:</div>
            <div className="h-4 bg-gray-800 rounded-sm flex-grow">
              <div 
                className="h-full bg-red-600 rounded-sm transition-all duration-300"
                style={{ width: `${(health / maxHealth) * 100}%` }}
              ></div>
            </div>
            <div className="text-white">{health}/{maxHealth}</div>
          </div>
        </div>
      </div>
      
      {/* Sound toggle button */}
      <div className="fixed top-4 right-4 z-10">
        <button 
          onClick={toggleMute}
          className="p-2 bg-gray-800 hover:bg-gray-700 rounded-full text-white"
        >
          {isMuted ? (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="1" y1="1" x2="23" y2="23"></line>
              <path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"></path>
              <path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path>
              <line x1="12" y1="19" x2="12" y2="23"></line>
              <line x1="8" y1="23" x2="16" y2="23"></line>
            </svg>
          ) : (
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path>
            </svg>
          )}
        </button>
      </div>
      
      {/* Controls info */}
      <div className="fixed bottom-4 left-4 z-10 text-white text-sm opacity-70">
        <div>WASD or Arrows: Move</div>
        <div>J or Space: Attack</div>
        <div>I: Inventory</div>
        <div>E: Interact</div>
        <div>ESC: Pause</div>
      </div>
      
      {/* Pause menu */}
      {showPauseMenu && gamePhase === 'paused' && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-black bg-opacity-75">
          <div className="bg-gray-900 text-white w-full max-w-md p-6 rounded-lg border border-gray-700">
            <h2 className="text-2xl font-bold text-center mb-8">Paused</h2>
            
            <div className="space-y-4">
              <button 
                onClick={resumeGame}
                className="w-full py-2 bg-red-900 hover:bg-red-800 font-bold rounded-sm transition-colors"
              >
                Resume Game
              </button>
              
              <button 
                onClick={() => toggleMute()}
                className="w-full py-2 bg-gray-800 hover:bg-gray-700 font-bold rounded-sm transition-colors"
              >
                Sound: {isMuted ? 'Off' : 'On'}
              </button>
              
              <button 
                onClick={exitToMenu}
                className="w-full py-2 bg-gray-800 hover:bg-gray-700 font-bold rounded-sm transition-colors"
              >
                Exit to Menu
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Dialogue UI */}
      <Dialogue />
      
      {/* Inventory UI */}
      <Inventory />
    </>
  );
}
