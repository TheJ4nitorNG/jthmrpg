import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "./utils/controls";

export default function Menu() {
  const { startGame, gamePhase, setGamePhase } = useGameState();
  const { backgroundMusic, toggleMute, isMuted } = useAudio();
  const [currentMenu, setCurrentMenu] = useState('main'); // 'main', 'settings', 'credits'
  const [subscribeKeys, getKeys] = useKeyboardControls();

  // Start the background music
  useEffect(() => {
    if (backgroundMusic && gamePhase === 'menu') {
      backgroundMusic.currentTime = 0;
      backgroundMusic.play().catch(error => {
        console.log("Background music prevented:", error);
      });
    }
    
    return () => {
      if (backgroundMusic) {
        backgroundMusic.pause();
      }
    };
  }, [backgroundMusic, gamePhase]);

  // Handle ESC key in sub-menus
  useEffect(() => {
    const unsubscribePause = subscribeKeys(
      (state) => state[Controls.pause],
      (pressed) => {
        if (pressed && currentMenu !== 'main') {
          setCurrentMenu('main');
        }
      }
    );
    
    return () => {
      unsubscribePause();
    };
  }, [subscribeKeys, currentMenu]);

  const handleStartGame = () => {
    startGame();
  };

  const handleSettings = () => {
    setCurrentMenu('settings');
  };

  const handleCredits = () => {
    setCurrentMenu('credits');
  };

  const handleBackToMainMenu = () => {
    setCurrentMenu('main');
  };

  const handleToggleSound = () => {
    toggleMute();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="w-full max-w-4xl p-8 relative">
        {/* Background styling */}
        <div className="absolute inset-0 border-2 border-red-800 m-4 z-0"></div>
        <div className="absolute inset-0 bg-black bg-opacity-80 m-4 z-0"></div>
        
        {/* Title */}
        <div className="relative z-10 mb-16 text-center">
          <h1 className="text-6xl font-bold text-red-600 mb-2">Johnny</h1>
          <h2 className="text-4xl font-bold text-gray-200">The Homicidal Maniac</h2>
          <p className="text-gray-400 mt-4">A Pixel RPG Adventure</p>
        </div>
        
        {/* Menu Content */}
        <AnimatePresence mode="wait">
          {currentMenu === 'main' && (
            <motion.div 
              key="main-menu"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10 flex flex-col items-center space-y-6"
            >
              <button 
                onClick={handleStartGame}
                className="w-64 py-3 bg-red-900 hover:bg-red-800 text-white font-bold text-xl rounded-sm transition-colors"
              >
                Start Game
              </button>
              
              <button 
                onClick={handleSettings}
                className="w-64 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xl rounded-sm transition-colors"
              >
                Settings
              </button>
              
              <button 
                onClick={handleCredits}
                className="w-64 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xl rounded-sm transition-colors"
              >
                Credits
              </button>
            </motion.div>
          )}
          
          {currentMenu === 'settings' && (
            <motion.div 
              key="settings-menu"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10 flex flex-col items-center"
            >
              <h3 className="text-2xl font-bold text-gray-200 mb-8">Settings</h3>
              
              <div className="space-y-6 mb-10">
                <div className="flex items-center justify-between w-64">
                  <span className="text-white">Sound</span>
                  <button 
                    onClick={handleToggleSound}
                    className={`px-4 py-2 rounded-sm ${isMuted ? 'bg-gray-800' : 'bg-red-900'}`}
                  >
                    {isMuted ? 'Off' : 'On'}
                  </button>
                </div>
                
                {/* More settings can be added here */}
              </div>
              
              <button 
                onClick={handleBackToMainMenu}
                className="w-64 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xl rounded-sm transition-colors"
              >
                Back to Main Menu
              </button>
            </motion.div>
          )}
          
          {currentMenu === 'credits' && (
            <motion.div 
              key="credits-menu"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10 flex flex-col items-center"
            >
              <h3 className="text-2xl font-bold text-gray-200 mb-8">Credits</h3>
              
              <div className="text-center space-y-4 mb-10">
                <div>
                  <h4 className="text-xl text-red-500">Based on</h4>
                  <p className="text-white">Johnny the Homicidal Maniac by Jhonen Vasquez</p>
                </div>
                
                <div>
                  <h4 className="text-xl text-red-500">Development</h4>
                  <p className="text-white">Your Friendly Developer</p>
                </div>
                
                <div>
                  <h4 className="text-xl text-red-500">Special Thanks</h4>
                  <p className="text-white">To all the JTHM fans</p>
                </div>
              </div>
              
              <button 
                onClick={handleBackToMainMenu}
                className="w-64 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xl rounded-sm transition-colors"
              >
                Back to Main Menu
              </button>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Footer */}
        <div className="relative z-10 mt-16 text-center text-gray-500 text-sm">
          <p>All rights to Johnny the Homicidal Maniac belong to Jhonen Vasquez</p>
        </div>
      </div>
    </div>
  );
}
