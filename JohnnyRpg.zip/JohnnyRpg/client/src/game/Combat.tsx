import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useKeyboardControls } from "@react-three/drei";
import { useGameState } from "@/lib/stores/useGameState";
import { useAudio } from "@/lib/stores/useAudio";
import { Controls } from "./utils/controls";

// Combat range in world units
const ATTACK_RANGE = 1.5;
// Attack cooldown in frames (60 frames = 1 second at 60fps)
const ATTACK_COOLDOWN = 30;
// Attack damage
const ATTACK_DAMAGE = 1;

export function useCombat() {
  const attackCooldown = useRef(0);
  const isAttacking = useRef(false);
  const [subscribeKeys, getKeys] = useKeyboardControls();
  const { playerPosition, gamePhase } = useGameState();
  const { playHit } = useAudio();
  
  // Subscribe to attack controls
  useEffect(() => {
    const unsubscribeAttack = subscribeKeys(
      (state) => state[Controls.attack],
      (pressed) => {
        if (pressed && attackCooldown.current === 0 && gamePhase === 'playing') {
          performAttack();
        }
      }
    );
    
    return () => {
      unsubscribeAttack();
    };
  }, [subscribeKeys, gamePhase]);
  
  // Update attack cooldown in game loop
  useFrame(() => {
    if (attackCooldown.current > 0) {
      attackCooldown.current--;
    }
    
    // Reset attack animation state
    if (isAttacking.current && attackCooldown.current < ATTACK_COOLDOWN - 10) {
      isAttacking.current = false;
    }
  });
  
  const performAttack = () => {
    if (gamePhase !== 'playing') return;
    
    console.log("Player attacks!");
    playHit();
    isAttacking.current = true;
    attackCooldown.current = ATTACK_COOLDOWN;
    
    // Get all enemies in the scene
    const scene = document.querySelector('canvas')?.object3D;
    if (!scene) return;
    
    // Check for enemies in range
    scene.traverse((object) => {
      if (object.type === 'Mesh' && object.parent && object.parent.userData?.isEnemy) {
        const enemyPos = new THREE.Vector3();
        object.getWorldPosition(enemyPos);
        
        // Calculate distance (using x-z plane since y is up/down)
        const distance = new THREE.Vector2(
          enemyPos.x - playerPosition.x,
          enemyPos.z - (-playerPosition.y) // Remember z is negative y in our setup
        ).length();
        
        if (distance < ATTACK_RANGE) {
          // Enemy is in range, damage it
          if (object.parent.takeDamage) {
            object.parent.takeDamage(ATTACK_DAMAGE);
            console.log("Hit enemy!");
          }
        }
      }
    });
  };
  
  return {
    isAttacking: () => isAttacking.current,
    attackCooldown: () => attackCooldown.current,
    performAttack
  };
}

export default function Combat() {
  useCombat();
  
  // This component doesn't render anything
  return null;
}
