// Simple AABB (Axis-Aligned Bounding Box) collision detection

export interface Box {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Circle {
  x: number;
  y: number;
  radius: number;
}

/**
 * Check if two boxes are colliding
 */
export function checkCollision(box1: Box, box2: Box): boolean {
  return (
    box1.x < box2.x + box2.width &&
    box1.x + box1.width > box2.x &&
    box1.y < box2.y + box2.height &&
    box1.y + box1.height > box2.y
  );
}

/**
 * Check if a circle is colliding with a box
 */
export function checkCircleBoxCollision(circle: Circle, box: Box): boolean {
  // Find the closest point on the box to the circle
  const closestX = Math.max(box.x, Math.min(circle.x, box.x + box.width));
  const closestY = Math.max(box.y, Math.min(circle.y, box.y + box.height));
  
  // Calculate distance between circle center and this closest point
  const distanceX = circle.x - closestX;
  const distanceY = circle.y - closestY;
  
  // If the distance is less than the circle's radius, there's a collision
  return (distanceX * distanceX + distanceY * distanceY) < (circle.radius * circle.radius);
}

/**
 * Check if two circles are colliding
 */
export function checkCircleCollision(circle1: Circle, circle2: Circle): boolean {
  const dx = circle1.x - circle2.x;
  const dy = circle1.y - circle2.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  return distance < (circle1.radius + circle2.radius);
}

/**
 * Check if a point is inside a box
 */
export function isPointInBox(x: number, y: number, box: Box): boolean {
  return (
    x >= box.x &&
    x <= box.x + box.width &&
    y >= box.y &&
    y <= box.y + box.height
  );
}
