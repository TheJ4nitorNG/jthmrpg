// Control definitions for the game

export enum Controls {
  forward = 'forward',
  backward = 'backward',
  leftward = 'leftward',
  rightward = 'rightward',
  attack = 'attack',
  interact = 'interact',
  inventory = 'inventory',
  pause = 'pause'
}

// Helper function to get the movement direction vector based on current key states
export function getMovementDirection(
  forward: boolean,
  backward: boolean,
  leftward: boolean,
  rightward: boolean
): [number, number] {
  let x = 0;
  let y = 0;
  
  if (forward) y += 1;
  if (backward) y -= 1;
  if (leftward) x -= 1;
  if (rightward) x += 1;
  
  // Normalize diagonal movement
  if (x !== 0 && y !== 0) {
    const length = Math.sqrt(x * x + y * y);
    x /= length;
    y /= length;
  }
  
  return [x, y];
}

// Debug key down event handler
export function debugKeyDown(event: KeyboardEvent): void {
  console.log(`Key down: ${event.code}`);
}

// Debug key up event handler
export function debugKeyUp(event: KeyboardEvent): void {
  console.log(`Key up: ${event.code}`);
}
