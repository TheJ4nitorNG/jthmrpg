import { useRef, useState, useEffect } from "react";
import { useGameState } from "@/lib/stores/useGameState";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "./utils/controls";
import { checkCollision } from "./utils/collisions";
import IntroLevel from "./levels/IntroLevel";
import { LevelData, levelMap } from "./levels/index";

export default function World() {
  const { currentLevel, gamePhase, setGamePhase, setPlayerPosition, playerPosition, dialogue, setDialogue } = useGameState();
  const worldRef = useRef<HTMLDivElement>(null);
  
  // Reference to level data
  const [levelData, setLevelData] = useState<LevelData | null>(null);
  const [walls, setWalls] = useState<Array<{ x: number; y: number; width: number; height: number }>>([]);
  
  // State for tracking camera/viewport position
  const [cameraPosition, setCameraPosition] = useState({ x: 0, y: 0 });
  const TILE_SIZE = 32; // Pixel size of each tile
  
  // Player movement state 
  const [facingDirection, setFacingDirection] = useState("down");
  const [isMoving, setIsMoving] = useState(false);
  const [subscribeKeys, getKeys] = useKeyboardControls();
  const speed = 0.1;
  const playerSize = 1;
  
  // Load level data
  useEffect(() => {
    console.log(`Loading level: ${currentLevel}`);
    // Load the current level
    const loadLevelData = async () => {
      try {
        // Dynamically import the level module
        let levelData;
        
        switch(currentLevel) {
          case 'intro':
            levelData = IntroLevel();
            break;
          case 'johnnys-house':
            // Dynamically import JohnnysHouse level
            const { default: JohnnysHouse } = await import('./levels/JohnnysHouse');
            levelData = JohnnysHouse();
            break;
          case 'wasteland':
            // Dynamically import Wasteland level
            const { default: Wasteland } = await import('./levels/Wasteland');
            levelData = Wasteland();
            break;
          case 'heaven':
            // Dynamically import Heaven level
            const { default: HeavenLevel } = await import('./levels/HeavenLevel');
            levelData = HeavenLevel();
            break;
          case 'neighbors-house':
            // Dynamically import NeighborsHouse level
            const { default: NeighborsHouse } = await import('./levels/NeighborsHouse');
            levelData = NeighborsHouse();
            break;
          default:
            // Default to intro level if not found
            console.warn(`Level ${currentLevel} not found, defaulting to intro`);
            levelData = IntroLevel();
        }
        
        setLevelData(levelData);
        setWalls(levelData.walls || []);
        
        // Set initial player position based on level data
        if (levelData.playerStart) {
          console.log("Setting initial player position:", levelData.playerStart);
          setPlayerPosition(levelData.playerStart);
          // Center camera on player initially
          setCameraPosition({ 
            x: -levelData.playerStart.x * TILE_SIZE + window.innerWidth / 2, 
            y: -levelData.playerStart.y * TILE_SIZE + window.innerHeight / 2 
          });
        }
        
        // Show level intro dialogue
        if (levelData.introDialogue) {
          setTimeout(() => {
            console.log(`Showing intro dialogue for level: ${levelData.name}`);
            setGamePhase('dialogue');
            setDialogue(levelData.introDialogue);
          }, 1000);
        }
      } catch (error) {
        console.error(`Error loading level ${currentLevel}:`, error);
      }
    };
    
    loadLevelData();
  }, [currentLevel, setPlayerPosition, setGamePhase, setDialogue]);

  // Function to check if player is in an exit area
  const checkExits = (playerPos: { x: number, y: number }) => {
    if (!levelData || !levelData.exits) return null;
    
    // Create player box for collision detection
    const playerBox = {
      x: playerPos.x - playerSize / 2,
      y: playerPos.y - playerSize / 2,
      width: playerSize,
      height: playerSize
    };
    
    // Check each exit
    for (const exit of levelData.exits) {
      if (checkCollision(playerBox, exit.position)) {
        // Check if exit is locked and requires a key
        if (exit.needsKey) {
          const hasKey = useGameState.getState().inventory.some(item => 
            item.id === exit.needsKey && item.type === 'key');
          
          if (!hasKey) {
            // Show message that exit is locked
            setDialogue({
              speaker: "Johnny",
              lines: [{ text: `This door is locked. I need to find a key.` }]
            });
            setGamePhase('dialogue');
            return null;
          }
        }
        
        // Return the exit that was triggered
        return exit;
      }
    }
    
    return null;
  };
  
  // Function to handle level transitions
  const changeLevel = (exit: any) => {
    // Set current level to the target level
    console.log(`Changing level to: ${exit.targetLevel}`);
    
    // First set the game phase to prevent movement during transition
    setGamePhase('paused');
    
    // Change the level in the game state
    setTimeout(() => {
      useGameState.getState().setCurrentLevel(exit.targetLevel);
      setPlayerPosition(exit.targetPosition);
      
      // Return to playing state after a short delay
      setTimeout(() => {
        setGamePhase('playing');
      }, 500);
    }, 500);
  };

  // Handle player movement with keyboard controls
  useEffect(() => {
    console.log("Setting up keyboard controls for 2D movement");
    
    // Player movement with WASD/arrows
    const playerMovementInterval = setInterval(() => {
      if (gamePhase !== 'playing') return;
      
      const keys = getKeys();
      let dirX = 0;
      let dirY = 0;
      
      // Determine movement direction
      if (keys[Controls.forward]) {
        dirY = -speed;
        setFacingDirection("up");
      } else if (keys[Controls.backward]) {
        dirY = speed;
        setFacingDirection("down");
      }
      
      if (keys[Controls.leftward]) {
        dirX = -speed;
        setFacingDirection("left");
      } else if (keys[Controls.rightward]) {
        dirX = speed;
        setFacingDirection("right");
      }
      
      // Update moving state
      setIsMoving(dirX !== 0 || dirY !== 0);
      
      if (!isMoving) return;
      
      // Calculate new position
      const newPosX = playerPosition.x + dirX;
      const newPosY = playerPosition.y + dirY;
      
      // Check for collisions
      const playerBox = {
        x: newPosX - playerSize / 2,
        y: newPosY - playerSize / 2,
        width: playerSize,
        height: playerSize
      };
      
      // Check for wall collisions
      let canMove = true;
      for (const wall of walls) {
        if (checkCollision(playerBox, wall)) {
          canMove = false;
          break;
        }
      }
      
      // Move player if no collisions
      if (canMove) {
        console.log(`Moving player to (${newPosX}, ${newPosY})`);
        setPlayerPosition({ x: newPosX, y: newPosY });
        
        // Check if player entered an exit area
        const triggeredExit = checkExits({ x: newPosX, y: newPosY });
        if (triggeredExit) {
          changeLevel(triggeredExit);
        }
      }
    }, 16); // 60 FPS
    
    return () => clearInterval(playerMovementInterval);
  }, [gamePhase, getKeys, isMoving, playerPosition, setPlayerPosition, walls, levelData, setGamePhase, setDialogue]);
  
  // Update camera to follow player
  useEffect(() => {
    const updateCamera = () => {
      if (!worldRef.current) return;
      
      // Center the player in the viewport with smooth scrolling
      const targetX = -playerPosition.x * TILE_SIZE + window.innerWidth / 2;
      const targetY = -playerPosition.y * TILE_SIZE + window.innerHeight / 2;
      
      setCameraPosition(prev => ({
        x: prev.x + (targetX - prev.x) * 0.1,
        y: prev.y + (targetY - prev.y) * 0.1
      }));
    };
    
    // Update camera position every animation frame
    const animationFrame = requestAnimationFrame(function update() {
      updateCamera();
      requestAnimationFrame(update);
    });
    
    return () => cancelAnimationFrame(animationFrame);
  }, [playerPosition]);

  if (!levelData) {
    return <div className="text-white">Loading level...</div>;
  }

  return (
    <div 
      ref={worldRef}
      className="absolute w-full h-full overflow-hidden"
      style={{
        backgroundColor: '#111',
        imageRendering: 'pixelated'
      }}
    >
      {/* Game world container - moves to simulate camera */}
      <div 
        className="absolute"
        style={{
          transform: `translate(${cameraPosition.x}px, ${cameraPosition.y}px)`,
          transition: 'transform 0.1s ease-out'
        }}
      >
        {/* Floor tiles */}
        <div className="absolute top-0 left-0 z-0">
          <Floor layout={levelData.layout} tileSize={TILE_SIZE} />
        </div>
        
        {/* Walls */}
        <div className="absolute top-0 left-0 z-10">
          <Walls walls={levelData.walls} tileSize={TILE_SIZE} />
        </div>
        
        {/* Items */}
        <div className="absolute top-0 left-0 z-20">
          <Items items={levelData.items} tileSize={TILE_SIZE} />
        </div>
        
        {/* NPCs */}
        <div className="absolute top-0 left-0 z-20">
          {levelData.npcs.map((npc, index) => (
            <div 
              key={`npc-${index}`}
              className="absolute"
              style={{
                left: npc.position[0] * TILE_SIZE - TILE_SIZE/2,
                top: npc.position[1] * TILE_SIZE - TILE_SIZE/2,
                width: TILE_SIZE,
                height: TILE_SIZE,
                backgroundImage: 'url("/textures/npc.svg")',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center'
              }}
            />
          ))}
        </div>
        
        {/* Exits - level transition points */}
        <div className="absolute top-0 left-0 z-15">
          {levelData.exits && levelData.exits.map((exit, index) => (
            <div 
              key={`exit-${index}`}
              className="absolute"
              style={{
                left: exit.position.x * TILE_SIZE,
                top: exit.position.y * TILE_SIZE,
                width: exit.position.width * TILE_SIZE,
                height: exit.position.height * TILE_SIZE,
                backgroundImage: 'url("/textures/exit.svg")',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
                opacity: 0.8
              }}
            />
          ))}
        </div>
        
        {/* Player */}
        <div 
          className="absolute z-30"
          style={{
            left: playerPosition.x * TILE_SIZE - TILE_SIZE/2,
            top: playerPosition.y * TILE_SIZE - TILE_SIZE/2,
            width: TILE_SIZE,
            height: TILE_SIZE,
            backgroundImage: 'url("/textures/johnny.svg")',
            backgroundSize: 'contain',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'center',
            transform: `scale(1.2)`, // Make player slightly larger
            filter: 'drop-shadow(2px 2px 0 black)' // Add shadow for visibility
          }}
        />
        
        {/* Game progress indicator */}
        <div className="fixed top-4 right-4 z-50 bg-black bg-opacity-70 p-2 rounded text-white text-xs">
          <div className="font-bold mb-1">Current Location: {levelData.name}</div>
          <div>Objectives: {levelData.objectives.filter(obj => obj.completed).length}/{levelData.objectives.length}</div>
          <div>Areas Explored: {Object.keys(levelMap).indexOf(currentLevel) + 1}/{Object.keys(levelMap).length}</div>
        </div>
        
        {/* Enemies */}
        <div className="absolute top-0 left-0 z-25">
          {levelData.enemies.map((enemy, index) => (
            <div 
              key={`enemy-${index}`}
              className="absolute"
              style={{
                left: enemy.position[0] * TILE_SIZE - TILE_SIZE/2,
                top: enemy.position[1] * TILE_SIZE - TILE_SIZE/2,
                width: TILE_SIZE,
                height: TILE_SIZE,
                backgroundImage: 'url("/textures/enemy.svg")',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
                filter: enemy.type === 'advanced' ? 'hue-rotate(30deg) brightness(0.8)' : ''
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// Define 2D component interfaces and functions
interface FloorProps {
  layout: { width: number; height: number };
  tileSize: number;
}

function Floor({ layout, tileSize }: FloorProps) {
  // Create a grid of floor tiles
  const tiles = [];
  for (let y = 0; y < layout.height; y++) {
    for (let x = 0; x < layout.width; x++) {
      tiles.push(
        <div 
          key={`floor-${x}-${y}`}
          className="absolute"
          style={{
            left: x * tileSize,
            top: y * tileSize,
            width: tileSize,
            height: tileSize,
            backgroundImage: 'url("/textures/floor.svg")',
            backgroundSize: 'cover'
          }}
        />
      );
    }
  }
  
  return <>{tiles}</>;
}

interface WallsProps {
  walls: Array<{ x: number; y: number; width: number; height: number }>;
  tileSize: number;
}

function Walls({ walls, tileSize }: WallsProps) {
  return (
    <>
      {walls.map((wall, index) => (
        <div 
          key={`wall-${index}`}
          className="absolute"
          style={{
            left: wall.x * tileSize,
            top: wall.y * tileSize,
            width: wall.width * tileSize,
            height: wall.height * tileSize,
            backgroundImage: 'url("/textures/wall.svg")',
            backgroundSize: `${tileSize}px ${tileSize}px`,
            backgroundRepeat: 'repeat'
          }}
        />
      ))}
    </>
  );
}

interface ItemsProps {
  items: Array<{
    id: string;
    name: string;
    position: [number, number];
    type: string;
    usable: boolean;
    [key: string]: any;
  }>;
  tileSize: number;
}

function Items({ items, tileSize }: ItemsProps) {
  return (
    <>
      {items.map((item, index) => (
        <div
          key={`item-${index}`}
          className="absolute"
          style={{
            left: item.position[0] * tileSize - tileSize/2,
            top: item.position[1] * tileSize - tileSize/2,
            width: tileSize,
            height: tileSize,
            backgroundImage: 'url("/textures/item.svg")',
            backgroundSize: 'contain',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'center'
          }}
        />
      ))}
    </>
  );
}