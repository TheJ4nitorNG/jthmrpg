import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GamePhase = 'menu' | 'playing' | 'paused' | 'dialogue' | 'inventory' | 'gameOver';

interface Dialogue {
  speaker: string;
  lines: { text: string, speaker?: string }[];
}

interface InventoryItem {
  id: string;
  name: string;
  type: string;
  description: string;
  icon?: string;
  usable: boolean;
  quantity?: number;
  [key: string]: any; // For additional item-specific properties
}

export interface GameState {
  // Game state
  gamePhase: GamePhase;
  previousGamePhase: GamePhase;
  currentLevel: string;
  
  // Player state
  health: number;
  maxHealth: number;
  playerPosition: { x: number, y: number };
  
  // Game mechanics
  dialogue: Dialogue | null;
  inventory: InventoryItem[];
  objectives: { id: string, text: string, completed: boolean }[];
  
  // Actions
  startGame: () => void;
  restartLevel: () => void;
  setGamePhase: (phase: GamePhase) => void;
  setPreviousGamePhase: (phase: GamePhase) => void;
  setPlayerPosition: (position: { x: number, y: number }) => void;
  damagePlayer: (amount: number) => void;
  healPlayer: (amount: number) => void;
  setDialogue: (dialogue: Dialogue | null) => void;
  addInventoryItem: (item: InventoryItem) => void;
  removeInventoryItem: (itemId: string) => void;
  completeObjective: (objectiveId: string) => void;
  
  // Level management
  setCurrentLevel: (levelId: string) => void;
}

export const useGameState = create<GameState>()(
  subscribeWithSelector((set, get) => ({
    // Initial game state
    gamePhase: 'menu',
    previousGamePhase: 'menu',
    currentLevel: 'intro',
    
    // Initial player state
    health: 10,
    maxHealth: 10,
    playerPosition: { x: 0, y: 0 },
    
    // Initial mechanics
    dialogue: null,
    inventory: [],
    objectives: [],
    
    // Actions
    startGame: () => {
      console.log("Starting game - setting game phase to playing");
      set({
        gamePhase: 'playing',
        health: 10,
        inventory: [],
        objectives: [
          { id: 'find_key', text: 'Find the basement key', completed: false },
          { id: 'enter_basement', text: 'Enter the basement', completed: false },
          { id: 'confront_demons', text: 'Confront your inner demons', completed: false }
        ]
      });
      
      // Show intro dialogue after a short delay
      const introDialogue = {
        speaker: "Johnny",
        lines: [
          { text: "Another sleepless night. The voices are getting louder..." },
          { text: "I need to go check on my... 'guest' in the basement." },
          { text: "Where did I put that key?" }
        ]
      };
      
      // Let the player see the game first before showing dialogue
      console.log("Scheduling intro dialogue in 2 seconds");
      setTimeout(() => {
        console.log("Setting game phase to dialogue and showing intro text");
        set({
          gamePhase: 'dialogue',
          dialogue: introDialogue
        });
      }, 2000);
    },
    
    restartLevel: () => {
      set({
        gamePhase: 'playing',
        health: get().maxHealth,
        playerPosition: { x: 0, y: 0 }
      });
    },
    
    setGamePhase: (phase) => {
      set({ gamePhase: phase });
    },
    
    setPreviousGamePhase: (phase) => {
      set({ previousGamePhase: phase });
    },
    
    setPlayerPosition: (position) => {
      set({ playerPosition: position });
    },
    
    damagePlayer: (amount) => {
      set((state) => {
        const newHealth = Math.max(0, state.health - amount);
        
        // Check for game over
        if (newHealth === 0) {
          return {
            health: newHealth,
            gamePhase: 'gameOver'
          };
        }
        
        return { health: newHealth };
      });
    },
    
    healPlayer: (amount) => {
      set((state) => ({
        health: Math.min(state.maxHealth, state.health + amount)
      }));
    },
    
    setDialogue: (dialogue) => {
      set({ dialogue });
    },
    
    addInventoryItem: (item) => {
      set((state) => {
        // Check if item is already in inventory
        const existingItemIndex = state.inventory.findIndex(i => i.id === item.id);
        
        if (existingItemIndex >= 0) {
          // If item exists and has quantity, increment it
          const updatedInventory = [...state.inventory];
          if (updatedInventory[existingItemIndex].quantity !== undefined) {
            updatedInventory[existingItemIndex].quantity! += item.quantity || 1;
          }
          return { inventory: updatedInventory };
        }
        
        // Otherwise add as new item
        return { inventory: [...state.inventory, item] };
      });
    },
    
    removeInventoryItem: (itemId) => {
      set((state) => ({
        inventory: state.inventory.filter(item => item.id !== itemId)
      }));
    },
    
    completeObjective: (objectiveId) => {
      set((state) => ({
        objectives: state.objectives.map(obj => 
          obj.id === objectiveId ? { ...obj, completed: true } : obj
        )
      }));
    },
    
    // Level management 
    setCurrentLevel: (levelId) => {
      console.log(`Changing level to: ${levelId}`);
      set({ currentLevel: levelId });
    }
  }))
);
