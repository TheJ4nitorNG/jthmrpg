import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useGameState } from "./lib/stores/useGameState";
import { Controls } from "./game/utils/controls";
import Menu from "./game/Menu";
import World from "./game/World";
import GameUI from "./game/GameUI";
import SoundManager from "./game/SoundManager";
import "@fontsource/inter";

// Define control keys for the game
const keyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.leftward, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.rightward, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.attack, keys: ["KeyJ", "Space"] },
  { name: Controls.interact, keys: ["KeyE"] },
  { name: Controls.inventory, keys: ["KeyI"] },
  { name: Controls.pause, keys: ["Escape"] },
];

// Main App component
function App() {
  const { gamePhase } = useGameState();
  const [showCanvas, setShowCanvas] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  // Load audio
  useEffect(() => {
    // Load audio files
    const backgroundMusic = new Audio("/sounds/background.mp3");
    backgroundMusic.loop = true;
    backgroundMusic.volume = 0.4;
    setBackgroundMusic(backgroundMusic);

    const hitSound = new Audio("/sounds/hit.mp3");
    setHitSound(hitSound);

    const successSound = new Audio("/sounds/success.mp3");
    setSuccessSound(successSound);

    // Show the canvas once everything is loaded
    setShowCanvas(true);
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {showCanvas && (
        <KeyboardControls map={keyMap}>
          {gamePhase === 'menu' && <Menu />}

          {(gamePhase === 'playing' || gamePhase === 'paused' || gamePhase === 'dialogue') && (
            <>
              {/* 2D Game Container */}
              <div 
                className="relative w-full h-full bg-gray-900"
                style={{ 
                  imageRendering: 'pixelated',
                  overflow: 'hidden'
                }}
              >
                {/* 2D World - this will replace the 3D Canvas */}
                <div className="absolute inset-0">
                  <World />
                </div>
                
                {/* Game UI overlay */}
                <GameUI />
              </div>
            </>
          )}

          <SoundManager />
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
